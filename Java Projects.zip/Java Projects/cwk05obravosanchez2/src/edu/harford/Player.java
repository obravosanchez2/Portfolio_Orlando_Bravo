/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Player {

    private String name;
    private Fraction score;

    public Player() {
        name = "Default";
        score = new Fraction(1, 1);
    }

    public String getName() {
        return name;
    }

    public Fraction getScore() {
        return score;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setScore(Fraction score) {
        if (score.getNumerator() <= score.getDenominator()) {
            this.score = score;
        }
    }

    public void win() {
        score.setNumerator(score.getNumerator() + 1);
        score.setDenominator(score.getDenominator() + 1);
    }

    public void lose() {
        score.setDenominator(score.getDenominator() + 1);
    }

    @Override
    public String toString() {
        return name + " has been successful "
                + score.getNumerator() + " out of "
                + score.getDenominator() + " tries.";
    }
}
