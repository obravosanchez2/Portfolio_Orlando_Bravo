/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Cwk05obravosanchez2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Fraction f1 = new Fraction();
        System.out.println(f1);

        Fraction f2 = new Fraction(3, 4);
        System.out.println(f2);

        Player p1 = new Player();
        p1.setName("Constance");
        p1.win();
        p1.lose();
        p1.win();
        System.out.println(p1);
    }
}
