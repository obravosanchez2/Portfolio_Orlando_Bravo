/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class AboutMe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        System.out.println("Hello from Orlando!");

        System.out.print("Hi from Jane Doe\n");

        System.out.print("Nice to meet you, group!");
        System.out.println();

        System.out.printf("For the low, low price of $%.2f! (+$%.2f shipping and handling)%n", 99.4411444, 4.0);
    }
}
