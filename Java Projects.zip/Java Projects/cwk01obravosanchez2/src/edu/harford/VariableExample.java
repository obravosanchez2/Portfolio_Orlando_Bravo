/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;
import java.util.Scanner;

public class VariableExample{

	public static void main(String[] args) {
	
		// scan is a Scanner, which we set up to let us read from the user
		Scanner scan = new Scanner(System.in);


		//=======================================
		// int, string, and double variables
		
		
		// declare variables, no assignment
		String str, str2;
		int i, i2;
		double d;

		// assign values
		i = 23778;
		d = 14.5667;
		// \n is newline,   \t is tab
		str = "the quick brown fox \n\tjumps over the lazy dog";
		
		
		// printing 
		// this + is string concatenation
		System.out.println("Your string was " + str);
		// int and double automatically cast to String
		System.out.println("Your int was " + i);
		System.out.println("Your double was " + d);
		// compile errors for trying to use uninitialized variables
		//System.out.println("Your other int was " + i2);
		//System.out.println("Your other String was " + str2);
		
		// compile errors for wrong type
		//i2 = "house";
		//str2 = 57;
		

		System.out.print("---Enter for next Example---");
		scan.nextLine();

		//=======================================
		// example of variables with values read in from the user


		// read values in, using Scanner
		System.out.println("Give me a string");
		str = scan.next(); // next anything, as a String
		System.out.println("Give me an integer");
		i = scan.nextInt(); // next int -- if not an int, program blows up
		System.out.println("Give me a double");
		d = scan.nextDouble(); // next double -- if not a double, program blows up
		
		// printing 
		System.out.println("Your string was " + str);
		System.out.println("Your int was " + i);
		System.out.println("Your double was " + d);
		
		// throw away anything else user typed on that line, including the newline
		scan.nextLine();
		

		
		System.out.print("---Enter for next Example---");
		scan.nextLine();

		//=======================================
		// examples of expressions

		str = "buckle my shoe";
		i = 42;
		d = 88.44;
				
		// i is automatically cast to a double
		double d2 = i + d;
		
		// loss of precision error
		//i2 = i + d;

		// explicit cast -- "I know what I'm about, son."
		i2 = i + (int)d;
		
		// concatenation causes implicit cast
		str2 = 57 + "";
			// number cast to a String: "57" + ""
			// now we can concatenate... with nothing: "57"
		
		System.out.println(i + " + " + d + " = " + i2 + " (as an int)");
		System.out.println(i + " + " + d + " = " + d2 + " (as a double)");
		System.out.println(str2 + " (is really a string)");
		
		// order of types determines which + to use
		System.out.println(str + i + d + " (string first)");
			// ----evaluation step by step:
			// str + i + d + " (string first)"
			// ----evaluate variables
			// "buckle my shoe" + 42 + 88.44 + " (string first)"
			// ----now left to right, so 42 cast to "42"
			// "buckle my shoe" + "42" + 88.44 + " (string first)"
			// "buckle my shoe42" + 88.44 + " (string first)"
			// "buckle my shoe42" + "88.44" + " (string first)"
			// "buckle my shoe4288.44" + " (string first)"
			// "buckle my shoe4288.44 (string first)"
			
		System.out.println(i + d + str + " (math first)");
		System.out.println(str + (i + d) + " (fixed with parens)");
		
		// order of operations
		i2 = 3 + 7 * i2 / i - 1;
		System.out.println("i2 = " + i2);
		d2 = d - d2 + 6 / 2 * 4;
		System.out.println("d2 = " + d2);
		
		// modulus operator
		int remainder = 44 % 3;
		System.out.println("remainder = " + remainder);
		
		// integer division
		double d3 = 10/7;
		System.out.println("d3 is "+ d3 + "??");
		// explicit cast before division
		d3 = (double)10/7;
		System.out.println("no, d3 should be "+ d3 );
		// explicit cast after division does nothing		
		d3 = (double)(10/7);
		System.out.println("oops, integer division strikes again: "+ d3 );		
	}


}
