/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Book implements Comparable<Book> {

    private String author;
    private String title;
    private String publisher;
    private int pages;
    private double price;

    public Book(String author, String title, String publisher, int pages, double price) {
        this.author = author;
        this.title = title;
        this.publisher = publisher;
        this.pages = pages;
        this.price = price;
    }

    public String getAuthor() {
        return author;
    }

    public String getTitle() {
        return title;
    }

    public String getPublisher() {
        return publisher;
    }

    public int getPages() {
        return pages;
    }

    public double getPrice() {
        return price;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String toString() {
        return "Title: " + title + "\n"
                + "Author: " + author + "\n"
                + "Publisher: " + publisher + "\n"
                + "Pages: " + pages + "\n"
                + String.format("Price: $%.2f\n", price)
                + "------------------------------";
    }

    public int compareTo(Book other) {
        int authorCompare = this.author.compareToIgnoreCase(other.author);
        if (authorCompare != 0) {
            return authorCompare;
        }
        return this.title.compareToIgnoreCase(other.title);
    }
}
