/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import java.util.Comparator;

/**
 *
 * @author orlan
 */
public class BookPagePriceComparator implements Comparator<Book> {

    public int compare(Book b1, Book b2) {
        if (b1 == null && b2 == null) {
            return 0;
        }
        if (b1 == null) {
            return -1;
        }
        if (b2 == null) {
            return 1;
        }

        int pageDiff = b1.getPages() - b2.getPages();
        if (pageDiff != 0) {
            return pageDiff;
        }

        return Double.compare(b1.getPrice(), b2.getPrice());
    }
}
