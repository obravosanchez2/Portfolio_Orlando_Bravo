/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import java.util.Comparator;

/**
 *
 * @author orlan
 */
public class BookPublisherComparator implements Comparator<Book> {

    public int compare(Book b1, Book b2) {
        if (b1 == null && b2 == null) {
            return 0;
        }
        if (b1 == null) {
            return -1;
        }
        if (b2 == null) {
            return 1;
        }

        int pubCompare = b1.getPublisher().compareToIgnoreCase(b2.getPublisher());
        if (pubCompare != 0) {
            return pubCompare;
        }

        return b1.compareTo(b2);
    }
}
