/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

import java.util.*;

/**
 *
 * @author orlan
 */
public class Cwk18obravosanchez2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        List<Book> books = new LinkedList<>();

        books.add(new Book("Author A", "Book 1", "Publisher X", 100, 15.00));
        books.add(new Book("Author B", "Book 1", "Publisher Y", 120, 16.00));
        books.add(new Book("Author A", "Book 2", "Publisher Z", 100, 15.00));
        books.add(new Book("Author C", "Book 3", "Publisher X", 200, 25.00));
        books.add(new Book("Author D", "Book 4", "Publisher X", 150, 30.00));
        books.add(new Book("Author E", "Book 5", "Publisher Y", 100, 15.00));
        books.add(new Book("Author F", "Book 6", "Publisher Z", 100, 15.00));
        books.add(new Book("Author G", "Book 7", "Publisher A", 150, 18.00));
        books.add(new Book("Author H", "Book 8", "Publisher B", 220, 60.00));
        books.add(new Book("Author I", "Book 9", "Publisher C", 300, 45.00));

        System.out.println("=== Unsorted Book List ===");
        printList(books);

        Collections.sort(books);
        System.out.println("\n=== Sorted by Author, then Title ===");
        printList(books);

        Collections.sort(books, new BookPagePriceComparator());
        System.out.println("\n=== Sorted by Pages, then Price ===");
        printList(books);

        Collections.sort(books, new BookPublisherComparator());
        System.out.println("\n=== Sorted by Publisher, then Author, then Title ===");
        printList(books);

        cheapen(books);
        System.out.println("\n=== After Removing Expensive Books (>$0.20/page) ===");
        printList(books);
    }

    public static void printList(List<Book> list) {
        for (Book b : list) {
            System.out.println(b);
        }
    }

    public static void cheapen(List<Book> list) {
        Iterator<Book> it = list.iterator();
        while (it.hasNext()) {
            Book b = it.next();
            if (b.getPrice() / b.getPages() > 0.20) {
                it.remove();
            }
        }
    }
}
