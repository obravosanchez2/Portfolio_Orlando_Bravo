/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public enum AptType {
    STUDIO("Studio", 520, 480),
    ONE_BEDROOM("1 Bedroom", 810, 720),
    TWO_BEDROOM("2 Bedroom", 1120, 1030),
    LUXURY("Luxury", 1720, 1780);

    public final String description;
    public final int size;
    public final int rent;

    private AptType(String description, int size, int rent) {
        this.description = description;
        this.size = size;
        this.rent = rent;
    }
}
