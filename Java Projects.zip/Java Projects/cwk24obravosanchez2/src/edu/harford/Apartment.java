/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Apartment {

    private AptType type;
    private boolean rented;

    private static final int FLOORS = 10;
    private static final int APTSPERFLOOR = AptType.values().length;
    private static final Apartment[][] building;

    static {
        building = new Apartment[FLOORS][APTSPERFLOOR];
        for (int i = 0; i < FLOORS; i++) {
            for (int j = 0; j < APTSPERFLOOR; j++) {
                building[i][j] = new Apartment(AptType.values()[j]);
            }
        }
    }

    public Apartment(AptType type) {
        this.type = type;
        this.rented = false;
    }

    public AptType getType() {
        return type;
    }

    public void setType(AptType type) {
        this.type = type;
    }

    public boolean isRented() {
        return rented;
    }

    public void setRented(boolean rented) {
        this.rented = rented;
    }

    public String toString() {
        return type.description + " | Size: " + type.size + " sq ft | Rent: $" + type.rent + "/mo | Rented: " + rented;
    }

    public static void rent(int floor, int num) {
        if (floor < 0 || floor >= FLOORS || num < 0 || num >= APTSPERFLOOR) {
            System.out.println("Invalid apartment selection.");
            return;
        }

        Apartment apt = building[floor][num];
        if (!apt.rented) {
            apt.rented = true;
            AptType t = apt.type;
            System.out.println("You are renting a " + t.size + " square foot " + t.description + " apartment for $" + t.rent + " / month.  Welcome to our building.");
        } else {
            System.out.println("Sorry, that apartment is already taken.");
        }
    }
}
