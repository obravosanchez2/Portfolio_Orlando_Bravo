/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author orlan
 */
public class Cwk10obravosanchez2 {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        String[] words = {"elephant", "dog", "hippopotamus", "cat"};
        int indexFromArray = shortestFinder(words);
        int indexFromVarArgs = shortestFinder("zebra", "lion", "ant", "giraffe");
        System.out.println("Shortest (array): " + words[indexFromArray] + " at index " + indexFromArray);
        System.out.println("Shortest (varargs): index " + indexFromVarArgs);

        int[][] table = makeMultTable(5);
        System.out.println("\nMultiplication Table:");
        for (int[] row : table) {
            System.out.println(Arrays.toString(row));
        }
        System.out.println("Sum of all elements: " + totalSum(table));

        int[] maxIndices = findMax(table);
        System.out.println("Largest value is at: row " + maxIndices[0] + ", col " + maxIndices[1] + ", value = " + table[maxIndices[0]][maxIndices[1]]);

        diceRecord(1000);
    }

    public static int shortestFinder(String... arr) {
        if (arr.length == 0) {
            return -1;
        }
        int shortestIndex = 0;
        int minLength = arr[0].length();
        for (int i = 1; i < arr.length; i++) {
            if (arr[i].length() < minLength) {
                minLength = arr[i].length();
                shortestIndex = i;
            }
        }
        return shortestIndex;
    }

    public static int[][] makeMultTable(int highest) {
        int[][] table = new int[highest + 1][highest + 1];
        for (int i = 0; i <= highest; i++) {
            for (int j = 0; j <= highest; j++) {
                table[i][j] = i * j;
            }
        }
        return table;
    }

    public static int totalSum(int[][] grid) {
        int sum = 0;
        for (int[] row : grid) {
            for (int val : row) {
                sum += val;
            }
        }
        return sum;
    }

    public static int[] findMax(int[][] grid) {
        int max = grid[0][0];
        int maxRow = 0, maxCol = 0;
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[i].length; j++) {
                if (grid[i][j] > max) {
                    max = grid[i][j];
                    maxRow = i;
                    maxCol = j;
                }
            }
        }
        return new int[]{maxRow, maxCol};
    }

    public static void diceRecord(int timesToRoll) {
        int[][] diceResults = new int[6][6];
        Random rand = new Random();
        for (int i = 0; i < timesToRoll; i++) {
            int die1 = rand.nextInt(6);
            int die2 = rand.nextInt(6);
            diceResults[die1][die2]++;
        }
        int[] maxIndices = findMax(diceResults);
        System.out.println("\nDice results (6x6):");
        for (int[] row : diceResults) {
            System.out.println(Arrays.toString(row));
        }
        System.out.println("Most frequent roll after " + timesToRoll + " rolls: "
                + (maxIndices[0] + 1) + " & " + (maxIndices[1] + 1)
                + " (" + diceResults[maxIndices[0]][maxIndices[1]] + " times)");
    }
}
