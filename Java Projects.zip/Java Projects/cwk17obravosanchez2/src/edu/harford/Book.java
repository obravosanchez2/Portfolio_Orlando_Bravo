/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Book implements Cloneable {

    private String author;
    private String title;
    private int copies;

    public Book(String author, String title, int copies) {
        this.author = author;
        this.title = title;
        this.copies = copies;
    }

    public Book(Book other) {
        this.author = other.author;
        this.title = other.title;
        this.copies = other.copies;
    }

    public Object clone() {
        return new Book(this);
    }

    public String getAuthor() {
        return author;
    }

    public String getTitle() {
        return title;
    }

    public int getCopies() {
        return copies;
    }

    public void addCopies(int n) {
        copies += n;
    }

    public void removeCopy() {
        copies--;
    }

    public boolean equals(Object o) {
        if (!(o instanceof Book)) {
            return false;
        }
        Book b = (Book) o;
        return author.equals(b.author) && title.equals(b.title);
    }

    public String toString() {
        return "(" + author + ", " + title + ", copies=" + copies + ")";
    }
}
