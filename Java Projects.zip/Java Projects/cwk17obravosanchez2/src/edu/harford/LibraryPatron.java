/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import java.util.*;

/**
 *
 * @author orlan
 */
public class LibraryPatron {

    private String name;
    private List<Book> current;

    public LibraryPatron(String name) {
        this.name = name;
        current = new ArrayList<>();
    }

    public void checkOut(String author, String title, Library lib) {
        if (current.size() >= 15) {
            System.out.println(name + " cannot check out more books (limit 15).");
            return;
        }

        Book b = lib.checkOut(author, title);
        if (b == null) {
            System.out.println(name + ": library does not have " + title);
        } else {
            current.add(b);
            System.out.println(name + " checked out " + b);
        }
    }

    public void returnBatch(Library lib) {
        int count = Math.min(5, current.size());
        Iterator<Book> it = current.iterator();
        int processed = 0;

        while (it.hasNext() && processed < count) {
            Book b = it.next();
            lib.checkIn(new Book(b));
            it.remove();
            processed++;
        }
    }

    public String toString() {
        return name + " has " + current;
    }
}
