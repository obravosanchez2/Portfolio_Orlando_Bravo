/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

import java.util.*;

/**
 *
 * @author orlan
 */
public class Cwk17obravosanchez2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Random r = new Random();

        Library branch1 = new Library();

        for (int i = 0; i < 30; i++) {
            String title = "Title " + i;
            String author = "Author " + i;
            int copies = r.nextInt(3) + 1;
            branch1.checkIn(new Book(author, title, copies));
        }

        for (int i = 0; i < 30; i++) {
            if (i % 7 == 0) {
                branch1.curate("Author " + i);
            }
        }

        for (int i = 0; i < 5; i++) {
            int idx = r.nextInt(40);
            branch1.checkOut("Author " + idx, "Title " + idx);
        }

        for (int i = 0; i < 5; i++) {
            int idx = r.nextInt(40);
            branch1.checkIn(new Book("Author " + idx, "Title " + idx, 1));
        }

        LibraryPatron p1 = new LibraryPatron("Patron1");
        LibraryPatron p2 = new LibraryPatron("Patron2");

        for (int i = 0; i < 8; i++) {
            int idx = r.nextInt(40);
            p1.checkOut("Author " + idx, "Title " + idx, branch1);
        }

        for (int i = 0; i < 20; i++) {
            int idx = r.nextInt(40);
            p2.checkOut("Author " + idx, "Title " + idx, branch1);
        }

        Library branch2 = new Library();

        p1.returnBatch(branch1);
        p1.returnBatch(branch2);

        p2.returnBatch(branch1);
        p2.returnBatch(branch2);

        System.out.println("\nBranch 1 inventory:\n" + branch1);
        System.out.println("\nBranch 2 inventory:\n" + branch2);
        System.out.println("\nPatrons:\n" + p1 + "\n" + p2);
    }
}
