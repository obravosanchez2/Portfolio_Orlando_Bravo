/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import java.util.*;

/**
 *
 * @author orlan
 */
public class Library {

    private List<Book> inventory;

    public Library() {
        inventory = new ArrayList<>(200);
    }

    public String toString() {
        return inventory.toString();
    }

    public void checkIn(Book b) {
        int idx = inventory.indexOf(b);
        if (idx == -1) {
            inventory.add(b);
        } else {
            inventory.get(idx).addCopies(b.getCopies());
        }
    }

    public Book checkOut(String author, String title) {
        Book temp = new Book(author, title, 1);
        int idx = inventory.indexOf(temp);
        if (idx == -1) {
            return null;
        }
        Book found = inventory.get(idx);

        if (found.getCopies() > 1) {
            found.removeCopy();
            return new Book(found.getAuthor(), found.getTitle(), 1);
        } else {
            inventory.remove(idx);
            return new Book(found);
        }
    }

    public void curate(String author) {
        Iterator<Book> it = inventory.iterator();
        while (it.hasNext()) {
            Book b = it.next();
            if (b.getAuthor().equals(author)) {
                it.remove();
            }
        }
    }
}
