/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class InterestAcct {
    private double balance;
    private double rate;
    private Person owner;

    public InterestAcct() {
        this(1.0, 0.01, null);
    }

    public InterestAcct(double balance, double rate, Person owner) {
        if (balance <= 0 || rate <= 0) throw new IllegalArgumentException("Balance and rate must be positive");
        this.balance = balance;
        this.rate = rate;
        this.owner = owner;
        if (owner != null) owner.setBank(this);
    }

    public double getBalance() { return this.balance; }
    public double getRate() { return this.rate; }

    public void newOwner(Person p) {
        if (p != null) {
            this.owner = p;
            p.setBank(this);
        }
    }

    public void merge(InterestAcct other) {
        if (other != null) {
            this.balance += (other.balance - 0.01);
            other.balance = 0.01;
        }
    }

    public double compoundTotal(int years) {
        double projected = this.balance;
        for (int i = 0; i < years; i++) {
            projected *= (1 + this.rate);
        }
        return projected;
    }

    public Person findNextOfKin() {
        if (owner == null) return null;
        if (owner.getDaughter() != null) return owner.getDaughter();
        if (owner.getSon() != null) return owner.getSon();
        if (owner.getSister() != null) return owner.getSister();
        if (owner.getBrother() != null) return owner.getBrother();
        if (owner.getMother() != null) return owner.getMother();
        if (owner.getFather() != null) return owner.getFather();
        return null;
    }

    public void death() {
        Person kin = findNextOfKin();
        if (kin != null) {
            this.balance *= 0.9;
            if (kin.getBank() != null) {
                kin.getBank().merge(this);
            } else {
                this.newOwner(kin);
            }
        } else {
            this.balance = 0.01;
            System.out.println("Bank claims money as abandoned.");
        }
    }
}
