/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Cwk08obravosanchez2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Person alice = new Person("Alice");
        Person bob = new Person("Bob");
        Person carol = new Person("Carol");

        alice.setDaughter(carol);
        bob.setSister(carol);

        InterestAcct acct1 = new InterestAcct(1000, 0.05, alice);
        InterestAcct acct2 = new InterestAcct(500, 0.03, bob);

        System.out.println(alice);
        System.out.println(bob);

        System.out.println("Alice after 5 years: $" + String.format("%.2f", acct1.compoundTotal(5)));

        alice.swapAccounts(bob);
        System.out.println("After swap:");
        System.out.println(alice);
        System.out.println(bob);

        acct1.merge(acct2);
        System.out.println("After merge: $" + String.format("%.2f", acct1.getBalance()));

        acct1.death();
        System.out.println("After Alice death: " + acct1.getBalance());
        System.out.println("Carol now: " + carol);
    }
}
