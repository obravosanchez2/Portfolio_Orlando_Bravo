/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */

public class Person {
    private String name;
    private Person daughter, son, sister, brother, mother, father;
    private InterestAcct bank;

    public Person(String name) {
        this.name = name;
    }

    public String getName() { return this.name; }

    public InterestAcct getBank() { return this.bank; }
    public void setBank(InterestAcct bank) { this.bank = bank; }

    public void setDaughter(Person daughter) { this.daughter = daughter; }
    public void setSon(Person son) { this.son = son; }
    public void setSister(Person sister) { this.sister = sister; }
    public void setBrother(Person brother) { this.brother = brother; }
    public void setMother(Person mother) { this.mother = mother; }
    public void setFather(Person father) { this.father = father; }

    public Person getDaughter() { return this.daughter; }
    public Person getSon() { return this.son; }
    public Person getSister() { return this.sister; }
    public Person getBrother() { return this.brother; }
    public Person getMother() { return this.mother; }
    public Person getFather() { return this.father; }

    public void swapAccounts(Person other) {
        if (other != null && other.getBank() != null && this.bank != null) {
            InterestAcct temp = this.bank;
            this.bank = other.bank;
            other.bank = temp;
            this.bank.newOwner(this);
            other.bank.newOwner(other);
        }
    }

    @Override
    public String toString() {
        String info = this.name;
        if (this.bank != null) {
            info += " with account balance: $" + String.format("%.2f", this.bank.getBalance());
        }
        return info;
    }
}