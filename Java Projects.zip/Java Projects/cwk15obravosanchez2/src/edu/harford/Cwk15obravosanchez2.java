/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Cwk15obravosanchez2 {

    public static void nature(Predator pr, Prey py) {
        System.out.println("\n--- Nature Event ---");
        if (pr.hunt(py)) {
            pr.eat(py);
        }
    }

    public static void main(String[] args) {

        nature(new RoboHunter(), new Bait());

        Predator[] predators = {
            new RoboHunter(),
            new Wolf(20),
            new Hyena(15)
        };

        Prey[] preyList = {
            new Bait(),
            new Mouse(10),
            new Hyena(12)
        };

        for (Predator p : predators) {
            for (Prey x : preyList) {
                nature(p, x);
            }
        }
    }
}
