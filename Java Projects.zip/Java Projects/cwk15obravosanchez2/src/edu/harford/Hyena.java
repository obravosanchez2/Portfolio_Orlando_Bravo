/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Hyena extends Animal implements Predator, Prey {

    public Hyena(int h) {
        super(h);
    }

    public boolean hunt(Prey p) {
        boolean success = this.health > p.nutrition();
        System.out.println(this + " hunts " + p + ": " + success);
        return success;
    }

    public void eat(Prey p) {
        System.out.println(this + " eats prey gaining " + p.nutrition());
        health += p.nutrition();
    }

    public int nutrition() {
        return health / 2;
    }

    public void sleep() {
        System.out.println(this + " sleeps under the moonlight.");
    }
}
