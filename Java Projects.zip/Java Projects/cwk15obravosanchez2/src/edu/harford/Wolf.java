/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import java.util.Random;

/**
 *
 * @author orlan
 */
public class Wolf extends Animal implements Predator {

    public Wolf(int h) {
        super(h);
    }

    public boolean hunt(Prey p) {
        boolean success = new Random().nextBoolean();
        System.out.println(this + " hunts " + p + ": " + success);
        return success;
    }

    public void eat(Prey p) {
        System.out.println(this + " eats prey gaining " + p.nutrition());
        health += p.nutrition();
    }

    public void sleep() {
        System.out.println(this + " sleeps in the den.");
    }
}
