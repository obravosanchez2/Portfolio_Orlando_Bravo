/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class RoboHunter implements Predator {

    public boolean hunt(Prey p) {
        System.out.println("RoboHunter hunts " + p + " and succeeds.");
        return true;
    }

    public void eat(Prey p) {
        System.out.println("RoboHunter destroys " + p + " with a laser.");
    }

    public String toString() {
        return "RoboHunter";
    }
}
