/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public abstract class Animal {

    protected int health;

    public Animal(int h) {
        this.health = h;
    }

    public int getHealth() {
        return health;
    }

    public abstract void sleep();

    public String toString() {
        return getClass().getSimpleName() + "(health=" + health + ")";
    }
}
