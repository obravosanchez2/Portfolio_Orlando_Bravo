/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Mouse extends Animal implements Prey {

    public Mouse(int h) {
        super(h);
    }

    public int nutrition() {
        return health;
    }

    public void sleep() {
        System.out.println(this + " sleeps quietly.");
    }
}
