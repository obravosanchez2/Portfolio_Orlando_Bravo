/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class BunnyFarmer {

    private String farmerName;
    private Bunny[] hutch;
    private int firstEmpty;

    public BunnyFarmer() {
        this.farmerName = "Unnamed Farmer";
        this.hutch = new Bunny[10];
        this.firstEmpty = 0;
    }

    public BunnyFarmer(String farmerName, Bunny[] startingBunnies) {
        this.farmerName = farmerName;
        this.hutch = new Bunny[startingBunnies.length * 2];
        this.firstEmpty = 0;
        for (Bunny b : startingBunnies) {
            this.hutch[firstEmpty++] = b;
        }
    }

    public void setFarmerName(String farmerName) {
        this.farmerName = farmerName;
    }

    public void addBunny(Bunny b) {
        if (firstEmpty < hutch.length) {
            hutch[firstEmpty++] = b;
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Farmer ").append(farmerName).append("\nBunny Hutch:\n");
        for (int i = 0; i < firstEmpty; i++) {
            sb.append((i + 1)).append(". ").append(hutch[i]).append("\n");
        }
        return sb.toString();
    }
}
