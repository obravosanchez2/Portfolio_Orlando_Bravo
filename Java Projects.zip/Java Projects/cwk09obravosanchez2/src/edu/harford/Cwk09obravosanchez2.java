/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Cwk09obravosanchez2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        boolean[] boolArray = makeBools(10);
        System.out.println("makeBools result:");
        for (int i = 0; i < boolArray.length; i++) {
            System.out.println(i + ": " + boolArray[i]);
        }

        String[] words = {"Hello", "world", "this", "is", "your", "message"};
        System.out.println("\nmashUp result: " + mashUp(words));

        String[] bunnyNames = {"Bun 1", "Mr. Bunnington", "Bugs", "Babs", "Buster"};
        Bunny[] bunnies = makeBunnies(bunnyNames);
        System.out.println("\nmakeBunnies result:");
        for (Bunny b : bunnies) {
            System.out.println(b);
        }

        BunnyFarmer farmer = new BunnyFarmer();
        farmer.setFarmerName("Bob");
        for (Bunny b : bunnies) {
            farmer.addBunny(b);
        }
        System.out.println("\n" + farmer);

        BunnyFarmer specialFarmer = new BunnyFarmer("Alice", bunnies);
        System.out.println(specialFarmer);

        BunnyFarmer[] farmers = new BunnyFarmer[3];
        farmers[0] = farmer;
        farmers[1] = specialFarmer;
        farmers[2] = new BunnyFarmer();
        farmers[2].setFarmerName("Charlie");

        System.out.println("\nAll Farmers:");
        for (BunnyFarmer f : farmers) {
            System.out.println(f);
        }
    }

    public static boolean[] makeBools(int size) {
        boolean[] arr = new boolean[size];
        for (int i = 0; i < size; i++) {
            if (i % 3 == 0) {
                arr[i] = true;
            }
        }
        return arr;
    }

    public static String mashUp(String[] arr) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < arr.length; i++) {
            sb.append(arr[i]);
            if (i < arr.length - 1) {
                sb.append(" ");
            }
        }
        return sb.toString();
    }

    public static Bunny[] makeBunnies(String[] names) {
        Bunny[] bunnyList = new Bunny[names.length];
        for (int i = 0; i < names.length; i++) {
            bunnyList[i] = new Bunny(names[i], i);
        }
        return bunnyList;
    }
}
