/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Bunny {

    private String name;
    private int carrotCount;

    public Bunny(String name, int carrotCount) {
        this.name = name;
        this.carrotCount = carrotCount;
    }

    public String getName() {
        return name;
    }

    public int getCarrotCount() {
        return carrotCount;
    }

    public void setName(String name) {
        if (name != null && !name.isEmpty()) {
            this.name = name;
        }
    }

    public void setCarrotCount(int carrotCount) {
        if (carrotCount >= 0) {
            this.carrotCount = carrotCount;
        }
    }

    @Override
    public String toString() {
        return "Bunny " + name + " (" + carrotCount + " carrots)";
    }
}
