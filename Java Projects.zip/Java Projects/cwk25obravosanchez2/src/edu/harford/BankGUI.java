/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import javax.swing.*;
import java.awt.*;
import java.io.*;

/**
 *
 * @author orlan
 */
public class BankGUI extends JFrame {

    private Account account;

    private JLabel accountLabel;
    private JLabel balanceLabel;

    private JButton depositBtn;
    private JButton withdrawBtn;
    private JButton interestBtn;
    private JButton saveBtn;

    private static final String FILE_NAME = "savedAccount.ser";

    public BankGUI() {
        super("Bank GUI");

        account = loadAccount();
        setupComponents();

        setLayout(new FlowLayout());
        add(accountLabel);
        add(balanceLabel);
        add(depositBtn);
        add(withdrawBtn);
        add(interestBtn);
        add(saveBtn);

        updateLabels();
        updateWithdrawButton();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setVisible(true);
    }

    private void setupComponents() {
        accountLabel = new JLabel();
        balanceLabel = new JLabel();

        depositBtn = new JButton("Quick Deposit");
        depositBtn.addActionListener(e -> {
            account.deposit(20);
            updateLabels();
            updateWithdrawButton();
        });

        withdrawBtn = new JButton("Quick Cash");
        withdrawBtn.addActionListener(e -> {
            if (account.withdraw(10)) {
                updateLabels();
                updateWithdrawButton();
            } else {
                JOptionPane.showMessageDialog(this, "Not enough money.");
            }
        });

        interestBtn = new JButton("Interest Payment");
        interestBtn.addActionListener(e -> {
            account.applyInterest();
            updateLabels();
            updateWithdrawButton();
        });

        saveBtn = new JButton("Save Account");
        saveBtn.addActionListener(e -> saveAccount());
    }

    private void updateLabels() {
        accountLabel.setText("Account Number: " + account.getAccountNumber());
        balanceLabel.setText(String.format("Balance: $%.2f", account.getBalance()));
    }

    private void updateWithdrawButton() {
        if (account.getBalance() < 10) {
            withdrawBtn.setText("Insufficient Funds");
        } else {
            withdrawBtn.setText("Quick Cash");
        }
    }

    private void saveAccount() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            out.writeObject(account);
            JOptionPane.showMessageDialog(this, "Account saved.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving account.");
        }
    }

    private Account loadAccount() {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            return (Account) in.readObject();
        } catch (Exception e) {
            int num = (int) (Math.random() * 900000 + 100000);
            return new Account(num, 0);
        }
    }

    public static void main(String[] args) {
        new BankGUI();
    }
}
