/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Contribution {

    private String email;
    private double amount;
    private int months;

    public Contribution() {
        email = "No Email";
        amount = 0.0;
        months = 1;
    }

    public Contribution(String email) {
        this();
        setEmail(email);
    }

    public Contribution(String email, double amount, int months) {
        this();
        setEmail(email);
        setAmount(amount);
        setMonths(months);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email != null && !email.trim().equals("")) {
            this.email = email;
        }
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        if (amount > 0) {
            this.amount = amount;
        }
    }

    public int getMonths() {
        return months;
    }

    public void setMonths(int months) {
        if (months >= 1) {
            this.months = months;
        }
    }

    @Override
    public String toString() {
        return "Email: " + email
                + ", Amount: $" + amount
                + ", Months: " + months;
    }
}