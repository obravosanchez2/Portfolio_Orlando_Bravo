/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author orlan
 */
public class ContributionGUI extends JFrame {

    private Contribution contribution;

    private JLabel emailLabel;
    private JLabel amountLabel;
    private JLabel monthsLabel;
    private JLabel totalLabel;

    private JTextField amountField;
    private JTextField monthsField;

    private JButton submitButton;

    public ContributionGUI() {

        String email = JOptionPane.showInputDialog(this, "Enter your email:");
        if (email == null || email.trim().equals("")) {
            email = "No Email";
        }

        contribution = new Contribution(email);

        setTitle("Contribution");
        setSize(350, 250);
        setLayout(new GridLayout(7, 1));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        emailLabel = new JLabel("Email: " + contribution.getEmail());
        amountLabel = new JLabel("Amount: $" + contribution.getAmount());
        monthsLabel = new JLabel("Months: " + contribution.getMonths());
        totalLabel = new JLabel("Total: $0.00");

        amountField = new JTextField();
        monthsField = new JTextField();

        submitButton = new JButton("Submit");
        submitButton.setEnabled(false);

        add(emailLabel);
        add(amountLabel);
        add(monthsLabel);
        add(totalLabel);
        add(amountField);
        add(monthsField);
        add(submitButton);

        amountField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    double amt = Double.parseDouble(amountField.getText());
                    if (amt > 0) {
                        contribution.setAmount(amt);
                        updateLabels();
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid amount!");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Not a number!");
                }
            }
        });

        monthsField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int m = Integer.parseInt(monthsField.getText());
                    if (m >= 1) {
                        contribution.setMonths(m);
                        updateLabels();
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid months!");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Not a number!");
                }
            }
        });

        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Thank you!");
            }
        });

        setVisible(true);
    }

    private void updateLabels() {
        amountLabel.setText("Amount: $" + contribution.getAmount());
        monthsLabel.setText("Months: " + contribution.getMonths());
        double total = contribution.getAmount() * contribution.getMonths();
        totalLabel.setText("Total: $" + total);

        if (contribution.getAmount() > 0.99) {
            submitButton.setEnabled(true);
        } else {
            submitButton.setEnabled(false);
        }
    }
}
