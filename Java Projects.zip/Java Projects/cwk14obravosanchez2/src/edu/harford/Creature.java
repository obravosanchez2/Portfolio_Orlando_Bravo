/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public abstract class Creature {

    protected int strength;

    public Creature(int strength) {
        this.strength = strength;
    }

    public Creature(Creature other) {
        this.strength = other.strength;
    }

    public int getStrength() {
        return strength;
    }

    public abstract void eat();

    public abstract void call();

    public abstract void move();

    public abstract Creature clone();

    public String toString() {
        return getClass().getSimpleName() + " (strength=" + strength + ")";
    }
}
