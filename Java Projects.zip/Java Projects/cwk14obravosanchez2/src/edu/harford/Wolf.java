/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Wolf extends Carnivore {

    public Wolf(int strength) {
        super(strength);
    }

    public Wolf(Wolf other) {
        super(other);
    }

    public void call() {
        System.out.println("Wolf howls at the moon.");
    }

    public void move() {
        System.out.println("Wolf runs swiftly through the forest.");
    }

    public Wolf clone() {
        return new Wolf(this);
    }

    public boolean equals(Object o) {
        if (!(o instanceof Wolf)) {
            return false;
        }
        Wolf other = (Wolf) o;
        return this.strength == other.strength;
    }
}
