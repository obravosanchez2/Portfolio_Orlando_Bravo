/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Cwk14obravosanchez2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Creature[] zoo = new Creature[10];

        zoo[0] = new Lion(20);
        zoo[1] = new Wolf(15);
        zoo[2] = new Rabbit(8);
        zoo[3] = new Turtle(12, 7);
        zoo[4] = new Lion(18);
        zoo[5] = new Wolf(11);
        zoo[6] = new Rabbit(10);
        zoo[7] = new Turtle(9, 5);
        zoo[8] = new Lion(25);
        zoo[9] = new Wolf(14);

        for (Creature c : zoo) {
            System.out.println("\n" + c);
            c.eat();
            c.move();
            c.call();
        }
    }
}
