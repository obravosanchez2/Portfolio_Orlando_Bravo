/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public abstract class Herbivore extends Creature {

    public Herbivore(int strength) {
        super(strength);
    }

    public Herbivore(Herbivore other) {
        super(other);
    }

    public void eat() {
        System.out.println(getClass().getSimpleName() + " eats vegetables.");
        strength += 2;
    }
}
