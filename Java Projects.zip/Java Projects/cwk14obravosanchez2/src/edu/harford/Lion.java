/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Lion extends Carnivore {

    public Lion(int strength) {
        super(strength);
    }

    public Lion(Lion other) {
        super(other);
    }

    public void call() {
        System.out.println("Lion roars with strength " + strength);
    }

    public void move() {
        System.out.println("Lion sprints across the savannah.");
    }

    public Lion clone() {
        return new Lion(this);
    }

    public boolean equals(Object o) {
        if (!(o instanceof Lion)) {
            return false;
        }
        Lion other = (Lion) o;
        return this.strength == other.strength;
    }
}
