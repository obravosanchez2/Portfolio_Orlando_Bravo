/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public abstract class Carnivore extends Creature {

    public Carnivore(int strength) {
        super(strength);
    }

    public Carnivore(Carnivore other) {
        super(other);
    }

    public void eat() {
        System.out.println(getClass().getSimpleName() + " eats meat.");
        strength += 5;
    }
}
