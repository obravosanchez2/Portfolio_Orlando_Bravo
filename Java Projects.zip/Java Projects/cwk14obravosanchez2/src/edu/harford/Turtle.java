/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Turtle extends Herbivore {

    private int shellHardness;

    public Turtle(int strength, int shellHardness) {
        super(strength);
        this.shellHardness = shellHardness;
    }

    public Turtle(Turtle other) {
        super(other);
        this.shellHardness = other.shellHardness;
    }

    public void call() {
        System.out.println("Turtle makes a low grunt.");
    }

    public void move() {
        System.out.println("Turtle crawls slowly. Shell hardness: " + shellHardness);
    }

    public Turtle clone() {
        return new Turtle(this);
    }

    public boolean equals(Object o) {
        if (!(o instanceof Turtle)) {
            return false;
        }
        Turtle other = (Turtle) o;
        return this.strength == other.strength
                && this.shellHardness == other.shellHardness;
    }

    public String toString() {
        return super.toString() + " (shellHardness=" + shellHardness + ")";
    }
}
