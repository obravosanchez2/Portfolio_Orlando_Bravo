/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Rabbit extends Herbivore {

    public Rabbit(int strength) {
        super(strength);
    }

    public Rabbit(Rabbit other) {
        super(other);
    }

    public void call() {
        System.out.println("Rabbit squeaks softly.");
    }

    public void move() {
        System.out.println("Rabbit hops quickly.");
    }

    public Rabbit clone() {
        return new Rabbit(this);
    }

    public boolean equals(Object o) {
        if (!(o instanceof Rabbit)) {
            return false;
        }
        Rabbit other = (Rabbit) o;
        return this.strength == other.strength;
    }
}
