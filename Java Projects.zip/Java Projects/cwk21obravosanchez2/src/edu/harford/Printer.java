/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import java.util.List;

/**
 *
 * @author orlan
 */
public class Printer {

    public static void print(List<HCCClass> list) {
        for (HCCClass c : list) {
            System.out.println(c);
        }
    }
}
