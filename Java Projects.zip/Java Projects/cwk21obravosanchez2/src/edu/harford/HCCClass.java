/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import java.io.Serializable;

/**
 *
 * @author orlan
 */
public class HCCClass implements Serializable {

    private String program;
    private String courseNumber;
    private int credits;
    private transient int fails;

    public HCCClass(String program, String courseNumber, int credits) {
        this.program = program;
        this.courseNumber = courseNumber;
        this.credits = credits;
    }

    public void fail() {
        this.fails++;
    }

    public int getFails() {
        return fails;
    }

    public String toString() {
        String s = program + " " + courseNumber + " (" + credits + ")";
        return fails > 0 ? s + " fails=" + fails : s;
    }
}
