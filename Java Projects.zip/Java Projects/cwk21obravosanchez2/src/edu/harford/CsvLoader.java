/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author orlan
 */
public class CsvLoader {

    public static List<HCCClass> load(String path) {
        List<HCCClass> list = new ArrayList<>();
        File csv = new File(path);
        if (!csv.exists()) {
            return list;
        }
        try {
            Scanner sc = new Scanner(new BufferedReader(new FileReader(csv)));
            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                if (line.isEmpty()) {
                    continue;
                }
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    String program = parts[0].trim();
                    String course = parts[1].trim();
                    int credits = Integer.parseInt(parts[2].trim());
                    HCCClass c = new HCCClass(program, course, credits);
                    if (parts.length >= 4) {
                        int fails = Integer.parseInt(parts[3].trim());
                        for (int i = 0; i < fails; i++) {
                            c.fail();
                        }
                    }
                    list.add(c);
                }
            }
            sc.close();
        } catch (IOException e) {
            list.clear();
        }
        return list;
    }
}
