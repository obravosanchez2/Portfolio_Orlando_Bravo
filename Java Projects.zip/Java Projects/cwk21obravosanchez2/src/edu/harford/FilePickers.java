/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import javax.swing.JFileChooser;
import java.io.File;

/**
 *
 * @author orlan
 */
public class FilePickers {

    public static File save() {
        JFileChooser fc = new JFileChooser();
        int c = fc.showSaveDialog(null);
        if (c == JFileChooser.CANCEL_OPTION) {
            return null;
        }
        return fc.getSelectedFile();
    }

    public static File open() {
        JFileChooser fc = new JFileChooser();
        int c = fc.showOpenDialog(null);
        if (c == JFileChooser.CANCEL_OPTION) {
            return null;
        }
        return fc.getSelectedFile();
    }
}
