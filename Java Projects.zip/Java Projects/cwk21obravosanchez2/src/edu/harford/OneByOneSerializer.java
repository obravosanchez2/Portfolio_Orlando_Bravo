/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author orlan
 */
public class OneByOneSerializer {

    public static void write(File file, List<HCCClass> list) {
        try {
            ObjectOutputStream out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(file)));
            for (HCCClass c : list) {
                if (c.getFails() <= 3) {
                    out.writeObject(c);
                }
            }
            out.writeObject(null);
            out.close();
        } catch (IOException e) {
            System.out.println("could not access file");
        }
    }

    public static List<HCCClass> read(File file) {
        List<HCCClass> outList = new ArrayList<>();
        try {
            ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(file)));
            Object o;
            do {
                o = in.readObject();
                if (o != null && o instanceof HCCClass) {
                    outList.add((HCCClass) o);
                }
            } while (o != null);
            in.close();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("could not access file");
        }
        return outList;
    }
}
