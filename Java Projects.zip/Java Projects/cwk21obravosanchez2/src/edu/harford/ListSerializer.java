/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author orlan
 */
public class ListSerializer {

    public static void write(File file, List<HCCClass> list) {
        try {
            ObjectOutputStream out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(file)));
            out.writeObject(list);
            out.close();
        } catch (IOException e) {
            System.out.println("could not access file");
        }
    }

    @SuppressWarnings("unchecked")
    public static List<HCCClass> read(File file) {
        List<HCCClass> list = new ArrayList<>();
        try {
            ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(file)));
            Object o = in.readObject();
            if (o instanceof List) {
                list = (List<HCCClass>) o;
            }
            in.close();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("could not access file");
        }
        return list;
    }
}
