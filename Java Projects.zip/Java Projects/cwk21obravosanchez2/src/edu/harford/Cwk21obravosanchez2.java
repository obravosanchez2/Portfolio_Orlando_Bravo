/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

import javax.swing.JFileChooser;
import java.io.*;
import java.util.*;

/**
 *
 * @author orlan
 */
public class Cwk21obravosanchez2 {

    static class HCCClass implements Serializable {

        private String program;
        private String courseNumber;
        private int credits;
        private transient int fails;

        public HCCClass(String program, String courseNumber, int credits) {
            this.program = program;
            this.courseNumber = courseNumber;
            this.credits = credits;
        }

        public void fail() {
            this.fails++;
        }

        public int getFails() {
            return fails;
        }

        public String toString() {
            String s = program + " " + courseNumber + " (" + credits + ")";
            return fails > 0 ? s + " fails=" + fails : s;
        }
    }

    public static void main(String[] args) {
        List<HCCClass> classes = loadFromCsvOrDefault();
        if (classes.size() < 5) {
            classes = defaultList();
        }
        if (!classes.isEmpty()) {
            for (int i = 0; i < 3; i++) {
                classes.get(0).fail();
            }
        }

        Scanner in = new Scanner(System.in);
        while (true) {
            System.out.println("Choose an option:");
            System.out.println("1) FirstMain - Create list, fail 3 times, print and serialize whole list");
            System.out.println("2) SecondMain - Open and read serialized list, then print it");
            System.out.println("3) ThirdMain (Extra Credit) - Serialize classes one by one (skip fails > 3) and write null at end");
            System.out.println("4) FourthMain (Extra Credit) - Read classes one by one until null and print them");
            System.out.println("0) Exit");
            String op = in.nextLine().trim();

            if (op.equals("0")) {
                break;
            } else if (op.equals("1")) {
                printList(classes);
                File saveWhole = chooseSave();
                if (saveWhole != null) {
                    writeWholeList(classes, saveWhole);
                }
            } else if (op.equals("2")) {
                File openWhole = chooseOpen();
                if (openWhole != null) {
                    List<HCCClass> loaded = readWholeList(openWhole);
                    printList(loaded);
                }
            } else if (op.equals("3")) {
                File saveOneByOne = chooseSave();
                if (saveOneByOne != null) {
                    writeOneByOne(classes, saveOneByOne);
                }
            } else if (op.equals("4")) {
                File openOneByOne = chooseOpen();
                if (openOneByOne != null) {
                    List<HCCClass> loaded = readOneByOne(openOneByOne);
                    printList(loaded);
                }
            }
        }
    }

    static void printList(List<HCCClass> list) {
        for (HCCClass c : list) {
            System.out.println(c);
        }
    }

    static File chooseSave() {
        JFileChooser fc = new JFileChooser();
        int choice = fc.showSaveDialog(null);
        if (choice == JFileChooser.CANCEL_OPTION) {
            return null;
        }
        return fc.getSelectedFile();
    }

    static File chooseOpen() {
        JFileChooser fc = new JFileChooser();
        int choice = fc.showOpenDialog(null);
        if (choice == JFileChooser.CANCEL_OPTION) {
            return null;
        }
        return fc.getSelectedFile();
    }

    static void writeWholeList(List<HCCClass> list, File file) {
        try {
            ObjectOutputStream out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(file)));
            out.writeObject(list);
            out.close();
        } catch (IOException e) {
            System.out.println("Could not access file");
        }
    }

    @SuppressWarnings("unchecked")
    static List<HCCClass> readWholeList(File file) {
        List<HCCClass> list = new ArrayList<>();
        try {
            ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(file)));
            Object o = in.readObject();
            if (o instanceof List) {
                list = (List<HCCClass>) o;
            }
            in.close();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Could not access file");
        }
        return list;
    }

    static void writeOneByOne(List<HCCClass> list, File file) {
        try {
            ObjectOutputStream out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(file)));
            for (HCCClass c : list) {
                if (c.getFails() <= 3) {
                    out.writeObject(c);
                }
            }
            out.writeObject(null);
            out.close();
        } catch (IOException e) {
            System.out.println("Could not access file");
        }
    }

    static List<HCCClass> readOneByOne(File file) {
        List<HCCClass> outList = new ArrayList<>();
        try {
            ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(file)));
            Object o;
            do {
                o = in.readObject();
                if (o != null && o instanceof HCCClass) {
                    outList.add((HCCClass) o);
                }
            } while (o != null);
            in.close();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Could not access file");
        }
        return outList;
    }

    static List<HCCClass> loadFromCsvOrDefault() {
        File csv = new File("transcript.csv");
        List<HCCClass> list = new ArrayList<>();
        if (csv.exists()) {
            try {
                Scanner sc = new Scanner(new BufferedReader(new FileReader(csv)));
                while (sc.hasNextLine()) {
                    String line = sc.nextLine().trim();
                    if (line.isEmpty()) {
                        continue;
                    }
                    String[] parts = line.split(",");
                    if (parts.length >= 3) {
                        String program = parts[0].trim();
                        String course = parts[1].trim();
                        int credits = Integer.parseInt(parts[2].trim());
                        HCCClass c = new HCCClass(program, course, credits);
                        if (parts.length >= 4) {
                            int fails = Integer.parseInt(parts[3].trim());
                            for (int i = 0; i < fails; i++) {
                                c.fail();
                            }
                        }
                        list.add(c);
                    }
                }
                sc.close();
            } catch (IOException e) {
                list = defaultList();
            }
        } else {
            list = defaultList();
        }
        return list;
    }

    static List<HCCClass> defaultList() {
        List<HCCClass> list = new ArrayList<>();
        list.add(new HCCClass("CS", "101", 3));
        list.add(new HCCClass("CS", "201", 4));
        list.add(new HCCClass("MATH", "109", 3));
        list.add(new HCCClass("ENG", "101", 3));
        list.add(new HCCClass("BIO", "120", 4));
        return list;
    }
}
