/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author orlan
 */
public class DefaultData {

    public static List<HCCClass> seed() {
        List<HCCClass> list = new ArrayList<>();
        list.add(new HCCClass("CS", "101", 3));
        list.add(new HCCClass("CS", "201", 4));
        list.add(new HCCClass("MATH", "109", 3));
        list.add(new HCCClass("ENG", "101", 3));
        list.add(new HCCClass("BIO", "120", 4));
        return list;
    }
}
