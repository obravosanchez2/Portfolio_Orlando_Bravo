/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

import java.util.Scanner;

/**
 *
 * @author orlan
 */
public class Cwk19obravosanchez2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        Student s = new Student();

        System.out.print("Enter first name: ");
        s.setFirstName(in.nextLine());

        System.out.print("Enter last name: ");
        s.setLastName(in.nextLine());

        boolean ok = false;
        while (!ok) {
            try {
                System.out.print("Enter age (3–120): ");
                String input = in.nextLine();
                int a = Integer.parseInt(input);
                s.setAge(a);
                ok = true;
            } catch (NumberFormatException e) {
                System.out.println("You must enter a whole number for age.");
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        ok = false;
        while (!ok) {
            try {
                System.out.print("Enter GPA (0.0–4.0): ");
                String input = in.nextLine();
                double g = Double.parseDouble(input);
                s.setGpa(g);
                ok = true;
            } catch (NumberFormatException e) {
                System.out.println("You must enter a valid decimal number for GPA.");
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        System.out.println("\nStudent info:");
        System.out.println(s);

        try {
            Student copy = new Student(null);
        } catch (IllegalArgumentException e) {
            System.out.println("Copy constructor exception caught: " + e.getMessage());
        }

        Student cloned = (Student) s.clone();
        System.out.println("Clone: " + cloned);
    }
}
