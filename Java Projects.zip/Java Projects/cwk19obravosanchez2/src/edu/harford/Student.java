/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Student implements Cloneable {

    private String firstName;
    private String lastName;
    private int age;
    private double gpa;

    public Student() {
        firstName = "";
        lastName = "";
        age = 0;
        gpa = 0.0;
    }

    public Student(String first, String last, int age, double gpa) {
        this();
        setFirstName(first);
        setLastName(last);
        setAge(age);
        setGpa(gpa);
    }

    public Student(Student other) {
        if (other == null) {
            throw new IllegalArgumentException("Cannot copy null Student");
        }
        this.firstName = other.firstName;
        this.lastName = other.lastName;
        this.age = other.age;
        this.gpa = other.gpa;
    }

    public Object clone() {
        return new Student(this);
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String first) {
        this.firstName = first;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String last) {
        this.lastName = last;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age < 3 || age > 120) {
            throw new IllegalArgumentException("Age must be between 3 and 120.");
        }
        this.age = age;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        if (gpa < 0.0 || gpa > 4.0) {
            throw new IllegalArgumentException("GPA must be between 0.0 and 4.0.");
        }
        this.gpa = gpa;
    }

    public String toString() {
        return firstName + " " + lastName + ", age " + age + ", GPA " + gpa;
    }
}
