/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class MyTriple<A, B, C> extends MyPair<A, B> {

    private C third;

    public MyTriple(A first, B second, C third) {
        super(first, second, "My Triple");
        this.third = third;
    }

    public C getThird() {
        return third;
    }

    public void setThird(C third) {
        this.third = third;
    }

    public String toString() {
        return getName() + ": (" + getFirst() + ", " + getSecond() + ", " + getThird() + ")";
    }
}
