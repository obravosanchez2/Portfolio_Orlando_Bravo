/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class MyPair<A, B> extends Namey {

    private A first;
    private B second;

    public MyPair() {
        super("An Empty Pair");
        first = null;
        second = null;
    }

    public MyPair(A vala, B valb) {
        super("My Pair");
        setFirst(vala);
        setSecond(valb);
    }

    public MyPair(A vala, B valb, String nval) {
        super(nval);
        setFirst(vala);
        setSecond(valb);
    }

    public A getFirst() {
        return first;
    }

    public void setFirst(A val) {
        first = val;
    }

    public B getSecond() {
        return second;
    }

    public void setSecond(B val) {
        second = val;
    }

    public boolean equals(Object other) {
        if (other != null && other instanceof MyPair) {
            MyPair p = (MyPair) other;
            return this.getName().equals(p.getName())
                    && this.getFirst().equals(p.getFirst())
                    && this.getSecond().equals(p.getSecond());
        }
        return false;
    }

    public String toString() {
        return getName() + ": (" + getFirst() + ", " + getSecond() + ")";
    }
}
