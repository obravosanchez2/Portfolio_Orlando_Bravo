/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

import java.util.Random;

/**
 *
 * @author orlan
 */
public class Cwk22obravosanchez2 {

    public static <T> void printBackward(T[] array) {
        if (array == null) {
            return;
        }
        for (int i = array.length - 1; i >= 0; i--) {
            System.out.println(array[i]);
        }
    }

    public static <T> T chooseRandom(T[] array) {
        if (array == null || array.length == 0) {
            return null;
        }
        Random r = new Random();
        return array[r.nextInt(array.length)];
    }

    public static <T extends Fighter> T fight(T first, T second) {
        System.out.println("Round 1:");
        first.attack();
        second.defend();
        System.out.println("Round 2:");
        second.attack();
        first.defend();
        if (Math.random() < 0.5) {
            System.out.println("Winner is first fighter!");
            return first;
        } else {
            System.out.println("Winner is second fighter!");
            return second;
        }
    }

    public static void main(String[] args) {

        Integer[] numbers = {1, 2, 3, 4, 5};
        String[] words = {"alpha", "beta", "gamma"};

        System.out.println("Integers backward:");
        printBackward(numbers);

        System.out.println("\nStrings backward:");
        printBackward(words);

        Ninja[] ninjas = {
            new Ninja("Ninja A"),
            new Ninja("Ninja B"),
            new Ninja("Ninja C")
        };

        String[] names = {"Alice", "Bob", "Charlie", "Diana"};

        Ninja chosenNinja = chooseRandom(ninjas);
        System.out.println("\nRandomly chosen ninja: " + chosenNinja);
        chosenNinja.assassinate("an unlucky target");

        String chosenName = chooseRandom(names);
        System.out.println("Randomly chosen name: " + chosenName);

        Ninja n1 = new Ninja("Shadow");
        Ninja n2 = new Ninja("Ghost");

        System.out.println("\nNinja vs Ninja fight:");
        Ninja winningNinja = fight(n1, n2);
        System.out.println("Winning ninja is: " + winningNinja);
        winningNinja.assassinate("another victim");

        Bee b1 = new Bee();
        Bee b2 = new Bee();

        System.out.println("\nBee vs Bee fight:");
        Bee winningBee = fight(b1, b2);
        System.out.println("Winning bee is: " + winningBee);
        winningBee.sting();

        MyTriple<Integer, Integer, String> triple1
                = new MyTriple<Integer, Integer, String>(1, 2, "three");

        MyTriple<String, Boolean, Double> triple2
                = new MyTriple<String, Boolean, Double>("open", true, 3.14);

        System.out.println("\nTesting MyTriple:");
        System.out.println(triple1);
        System.out.println(triple2);
    }
}
