/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Ninja extends Namey implements Fighter {

    public Ninja() {
        super("Ninja");
        System.out.println("A ninja was created.  This is the last warning you will ever have.");
    }

    public Ninja(String n) {
        super(n);
    }

    public boolean getVisible() {
        return false;
    }

    public void setVisible(boolean visible) {
    }

    public void attack() {
        System.out.println("The ninja killed you earlier, when you weren't watching.  Have a nice day.");
    }

    public void defend() {
        System.out.println("The ninja is safe. You can't hit what you can't see.");
    }

    public void assassinate(Object victim) {
        System.out.println(victim + " will never see the ninja coming.");
        if (victim instanceof Ninja) {
            System.out.println("Professional courtesy forbids me to kill other ninjas.");
        } else {
            attack();
        }
    }

    public String toString() {
        return getName();
    }

    public boolean equals(Object obj) {
        return false;
    }
}
