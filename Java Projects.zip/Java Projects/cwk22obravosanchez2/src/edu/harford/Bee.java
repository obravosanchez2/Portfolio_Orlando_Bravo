/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Bee implements Fighter {

    private static int sizeofHive;
    private static Bee[] swarm;
    private static int numBees;
    private static int swarmAttackChance;

    static {
        sizeofHive = 0;
        numBees = 0;
        swarm = new Bee[100];
        new Bee();
        swarmAttackChance = 10;
    }

    public Bee() {
        joinSwarm();
    }

    public static int getSizeofHive() {
        return sizeofHive;
    }

    public static void setSizeofHive(int sizeofHive) {
        Bee.sizeofHive = sizeofHive;
    }

    public void joinSwarm() {
        if (numBees < swarm.length) {
            swarm[numBees++] = this;
            swarmAttackChance++;
        }
    }

    public void swarmAttack() {
        System.out.println("SWARM ATTACK!");
        for (int i = 0; i < numBees; i++) {
            System.out.print(i + " ");
            swarm[i].sting();
        }
    }

    public void sting() {
        System.out.println("The bee stings!");
        if ((int) (Math.random() * swarmAttackChance) == 1) {
            int temp = swarmAttackChance;
            swarmAttackChance *= 10;
            swarmAttack();
            swarmAttackChance = temp;
        }
    }

    public void defend() {
        System.out.println("The bee stings some more!");
    }

    public void attack() {
        sting();
    }

    public void buildTheHive() {
        if (getSizeofHive() == 0) {
            System.out.println("The bees have started a new hive");
        }
        sizeofHive++;
        System.out.println(hiveReport());
    }

    public void doWork() {
        buildTheHive();
    }

    public static String hiveReport() {
        return "The hive is now " + sizeofHive + " inches high";
    }

    public static String swarmReport() {
        return "There are now " + numBees + " in the swarm";
    }

    public String toString() {
        return "one bee out of " + numBees;
    }

    public boolean equals(Object obj) {
        if (obj != null && obj instanceof Bee) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        int hash = 31;
        return hash;
    }
}
