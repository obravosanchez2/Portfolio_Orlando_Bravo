/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Coordinate extends MyPair<Integer, Integer> {

    public Coordinate() {
        super(0, 0, "");
    }

    public Coordinate(int v1, int v2) {
        super(v1, v2);
    }

    public double distance(Coordinate other) {
        return Math.sqrt(
                (getFirst() - other.getFirst()) * (getFirst() - other.getFirst())
                + (getSecond() - other.getSecond()) * (getSecond() - other.getSecond()));
    }

    public String toString() {
        return "(" + getFirst() + ", " + getSecond() + ")";
    }
}
