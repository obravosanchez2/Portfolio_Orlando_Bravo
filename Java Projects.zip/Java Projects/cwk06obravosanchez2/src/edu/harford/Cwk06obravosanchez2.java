/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Cwk06obravosanchez2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Taxpayer t1 = new Taxpayer(93000, 30, false);
        System.out.println(t1);
        t1.printTax();

        System.out.println();

        Taxpayer t2 = new Taxpayer(88000, 23, true);
        System.out.println(t2);
        t2.printTax();

        System.out.println();

        Taxpayer t3 = new Taxpayer(9000, 40, false);
        System.out.println(t3);
        t3.printTax();
    }
}
