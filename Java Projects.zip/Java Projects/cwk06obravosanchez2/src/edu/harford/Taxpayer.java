/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Taxpayer {

    private double income;
    private int age;
    private boolean married;

    public Taxpayer() {
        this(50000, 30, false);
    }

    public Taxpayer(double income, int age, boolean married) {
        setIncome(income);
        setAge(age);
        this.married = married;
    }

    public double getIncome() {
        return income;
    }

    public int getAge() {
        return age;
    }

    public boolean isMarried() {
        return married;
    }

    public void setIncome(double income) {
        this.income = income < 0 ? 0 : income;
    }

    public void setAge(int age) {
        this.age = age < 0 ? 0 : age;
    }

    public void setMarried(boolean married) {
        this.married = married;
    }

    @Override
    public String toString() {
        return (married ? "a married taxpayer" : "a taxpayer")
                + " (" + age + ") making $" + income;
    }

    public void printTax() {
        double taxableIncome = income;
        double tax = 0;
        if (married) {
            taxableIncome -= 8000;
        } else {
            taxableIncome -= 5000;
        }
        if (age <= 12 || age > 65) {
            taxableIncome -= 1000;
        }
        if (taxableIncome < 0) {
            taxableIncome = 0;
        }
        double remaining = taxableIncome;
        char bracket;
        if (taxableIncome > 375000) {
            bracket = 'F';
        } else if (taxableIncome > 175000) {
            bracket = 'E';
        } else if (taxableIncome > 85000) {
            bracket = 'D';
        } else if (taxableIncome > 35000) {
            bracket = 'C';
        } else if (taxableIncome > 10000) {
            bracket = 'B';
        } else {
            bracket = 'A';
        }
        System.out.println("Your taxed income: $" + taxableIncome);
        switch (bracket) {
            case 'F':
                double over375 = remaining - 375000;
                tax += over375 * 0.35;
                System.out.println("You had $" + over375 + " in the 35% bracket, on which you paid $" + (over375 * 0.35));
                remaining -= over375;
            case 'E':
                double over175 = remaining - 175000;
                tax += over175 * 0.33;
                System.out.println("You had $" + over175 + " in the 33% bracket, on which you paid $" + (over175 * 0.33));
                remaining -= over175;
            case 'D':
                double over85 = remaining - 85000;
                tax += over85 * 0.28;
                System.out.println("You had $" + over85 + " in the 28% bracket, on which you paid $" + (over85 * 0.28));
                remaining -= over85;
            case 'C':
                double over35 = remaining - 35000;
                tax += over35 * 0.25;
                System.out.println("You had $" + over35 + " in the 25% bracket, on which you paid $" + (over35 * 0.25));
                remaining -= over35;
            case 'B':
                double over10 = remaining - 10000;
                tax += over10 * 0.15;
                System.out.println("You had $" + over10 + " in the 15% bracket, on which you paid $" + (over10 * 0.15));
                remaining -= over10;
            case 'A':
                tax += remaining * 0;
                System.out.println("You had $" + remaining + " in the 0% bracket, on which you paid $0.0");
        }
        System.out.println("From an income of $" + income
                + (tax > 0 ? " you owe $" + tax + " tax and your remaining income is $" + (income - tax) + "."
                        : " you owe no tax and your remaining income is $" + income + "."));
    }
}
