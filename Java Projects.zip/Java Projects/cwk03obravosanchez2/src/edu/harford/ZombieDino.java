/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class ZombieDino {
    public String name;
    public int citiesStomped;
    
    public void stompCity(){
        citiesStomped++;
        System.out.println(name + " stomped another city! Total: " + citiesStomped);
    }
    
    public void roar() {
        System.out.println(name + " lets out a terrifying roar that shakes the ground!");
    }
     
    public String toString() {
        return "Zombie Dino " + name + " has stomped " + citiesStomped + " cities.";
    }
}
