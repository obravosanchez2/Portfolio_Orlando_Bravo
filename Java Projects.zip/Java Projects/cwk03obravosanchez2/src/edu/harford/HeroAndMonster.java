/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class HeroAndMonster {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Hero hero = new Hero();
        hero.name = "Steve";
        hero.hit_points = 10;
        hero.rest();
        hero.run();
        
        Monster monster = new Monster();
        monster.myName = "Ally";
        monster.peopleEaten = 0;
        monster.attack();
        hero.enemy = monster;
        System.out.println("The heros enemy is: " + hero.enemy.myName);
        monster.eat(hero);
        System.out.println("Heros new name: " + hero.name);
        System.out.println("Heros hit points: " + hero.hit_points);
        
        ZombieDino dino = new ZombieDino();
        dino.name = "Rex";
        dino.citiesStomped = 0;
        dino.stompCity();
        dino.stompCity();
        dino.roar();
        System.out.println(dino);
    }
    
}
