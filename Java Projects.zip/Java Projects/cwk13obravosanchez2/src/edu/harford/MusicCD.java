/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class MusicCD extends InventoryItem {

    private String performer;

    public MusicCD(String title, String performer, double price, int howMany) {
        super(title, price, howMany);
        this.performer = performer;
    }

    public MusicCD(MusicCD other) {
        super(other);
        this.performer = other.performer;
    }

    public MusicCD clone() {
        return new MusicCD(this);
    }

    public boolean equals(Object obj) {
        return obj instanceof MusicCD
                && super.equals(obj)
                && this.performer.equals(((MusicCD) obj).performer);
    }

    public void view() {
        System.out.println("Now Playing Sample: " + getDescription());
    }

    public String toString() {
        return "CD: " + performer + ": " + getDescription() + " ($" + getPrice() + ")";
    }

    public String getPerformer() {
        return performer;
    }
}
