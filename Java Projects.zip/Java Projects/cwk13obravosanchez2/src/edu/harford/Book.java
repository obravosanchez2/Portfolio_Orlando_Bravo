/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Book extends InventoryItem {

    private String author;

    public Book(String title, String author, double price, int howMany) {
        super(title, price, howMany);
        this.author = author;
    }

    public Book(Book other) {
        super(other);
        this.author = other.author;
    }

    public Book clone() {
        return new Book(this);
    }

    public boolean equals(Object obj) {
        return obj instanceof Book
                && super.equals(obj)
                && this.author.equals(((Book) obj).author);
    }

    public void view() {
        System.out.println("Opening Book Excerpt: " + getDescription());
    }

    public String toString() {
        return "Book: " + getDescription() + " by " + author + " ($" + getPrice() + ")";
    }

    public String getAuthor() {
        return author;
    }
}
