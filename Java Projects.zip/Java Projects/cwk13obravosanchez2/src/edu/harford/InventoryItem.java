/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class InventoryItem {

    private String description;
    private double price;
    private int howMany;

    public InventoryItem(String description, double price, int howMany) {
        setDescription(description);
        setPrice(price);
        setHowMany(howMany);
    }

    public InventoryItem(InventoryItem other) {
        this.description = other.description;
        this.price = other.price;
        this.howMany = 1;
    }

    public InventoryItem clone() {
        return new InventoryItem(this);
    }

    public boolean equals(Object obj) {
        if (obj instanceof InventoryItem) {
            InventoryItem other = (InventoryItem) obj;
            return this.description.equals(other.description)
                    && this.price == other.price;
        }
        return false;
    }

    public void view() {
        System.out.println("Viewing: " + description);
    }

    public String toString() {
        return description + " ($" + price + ")";
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }

    public int getHowMany() {
        return howMany;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setPrice(double price) {
        this.price = Math.max(0, price);
    }

    public void setHowMany(int howMany) {
        this.howMany = Math.max(0, howMany);
    }
}
