/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Cwk13obravosanchez2 {

    public static void main(String[] args) {
        InventoryItem item1 = new InventoryItem("Footo the Wonder Boot Exploder", 22.99, 3);
        InventoryItem item2 = item1.clone();

        System.out.println(item1);
        System.out.println(item2);
        System.out.println("Equals Inventory: " + item1.equals(item2));
        item1.view();

        InventoryItem b1 = new Book("The Curse of the Flying Wombat", "Constance deCoverlet", 12.95, 1);
        InventoryItem b2 = b1.clone();
        System.out.println(b1);
        System.out.println(b2);
        System.out.println("Equals Book: " + b1.equals(b2));
        b1.view();

        InventoryItem c1 = new MusicCD("Gnosis Greatest Hits vol 1", "Tommy Gnosis Band", 18.65, 2);
        InventoryItem c2 = c1.clone();
        System.out.println(c1);
        System.out.println(c2);
        System.out.println("Equals CD: " + c1.equals(c2));
        c1.view();
    }
}
