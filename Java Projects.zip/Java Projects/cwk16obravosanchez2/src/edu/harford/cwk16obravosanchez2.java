/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class cwk16obravosanchez2 {

    public static void main(String[] args) {
        BigDarnHero hero = new BigDarnHero("Mighty Thog", 5, 3);
        System.out.println("Before moving: " + hero);
        hero.move("N");
        hero.move("N");
        hero.move("N");
        hero.move("W");
        System.out.println("After walking: " + hero);

        hero.speedUp();
        hero.move("E");
        hero.move("E");
        hero.move("N");
        System.out.println("After running: " + hero);

        hero.slowDown();
        hero.move("S");
        hero.move("S");
        System.out.println("After slowing down: " + hero);

        hero.curse();
        hero.move("W");
        hero.move("N");
        System.out.println("After cursed movements: " + hero);

        System.out.println("\n--- PART E ---");
        Horse horse = new Horse("Mr. Ed", 4, 1);
        System.out.println("Before horse moves: " + horse);
        horse.move("E");
        horse.move("E");
        horse.move("S");
        horse.move("S");
        horse.move("S");
        horse.move("S");
        System.out.println("After horse moves: " + horse);

        BigDarnHero rider = new BigDarnHero("Mighty Thog", 2, 6);
        rider.setMoveStrat(horse);
        System.out.println("\nMighty Thog mounts the horse!");
        rider.move("W");
        rider.move("W");
        rider.move("W");
        System.out.println("After riding: " + rider);
    }
}
