/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class RandomCursedMoveStrategy implements MoveStrategy {

    public void move(Position p, String dir) {
        int oldX = p.getX();
        int oldY = p.getY();
        int dx = (int) (Math.random() * 1000 - 500);
        int dy = (int) (Math.random() * 1000 - 500);

        p.setX(oldX + dx);
        p.setY(oldY + dy);

        System.out.println("I moved from (" + oldX + "," + oldY + ") to " + p + ", truly, I am accursed and shall never get to class on time.");
    }

    public boolean chanceToFall() {
        return Math.random() < 0.5;
    }
}
