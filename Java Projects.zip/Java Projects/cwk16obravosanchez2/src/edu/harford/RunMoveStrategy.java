/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class RunMoveStrategy implements MoveStrategy {

    public void move(Position p, String dir) {
        int oldX = p.getX();
        int oldY = p.getY();

        if (dir.equalsIgnoreCase("N")) {
            p.setY(oldY + 5);
        } else if (dir.equalsIgnoreCase("S")) {
            p.setY(oldY - 5);
        } else if (dir.equalsIgnoreCase("E")) {
            p.setX(oldX + 5);
        } else if (dir.equalsIgnoreCase("W")) {
            p.setX(oldX - 5);
        }

        System.out.println("Running from (" + oldX + "," + oldY + ") to " + p + ". Boy my mighty thews are tired.");
    }

    public boolean chanceToFall() {
        return (int) (Math.random() * 10) == 0;
    }
}
