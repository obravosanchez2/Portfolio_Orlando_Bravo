/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Horse extends GameElt implements MoveStrategy {

    public Horse() {
        super("Unnamed Horse", 0, 0);
        setMoveStrat(this);
    }

    public Horse(String name, int x, int y) {
        super(name, x, y);
        setMoveStrat(this);
    }

    public void move(Position p, String dir) {
        int oldX = p.getX();
        int oldY = p.getY();
        if (dir.equalsIgnoreCase("N")) {
            p.setY(oldY + 10);
        } else if (dir.equalsIgnoreCase("S")) {
            p.setY(oldY - 10);
        } else if (dir.equalsIgnoreCase("E")) {
            p.setX(oldX + 10);
        } else if (dir.equalsIgnoreCase("W")) {
            p.setX(oldX - 10);
        }
        System.out.println(getName() + " gallops like the wind from (" + oldX + "," + oldY + ") to " + p + ".");
    }

    public boolean chanceToFall() {
        return (int) (Math.random() * 30) == 0;
    }

    public void move(String dir) {
        move(getPos(), dir);
        if (chanceToFall()) {
            System.out.println(getName() + " stumbled and fell!");
            setHealth(getHealth() - 5);
        }
    }

    public String toString() {
        return getName() + " the Horse " + getPos();
    }
}
