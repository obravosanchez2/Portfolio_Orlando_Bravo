/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public abstract class GameElt {

    private String name;
    private int health;
    private Position pos;
    private MoveStrategy moveStrat;

    public GameElt() {
        setName("Unknown");
        setHealth(100);
        setPos(new Position(0, 0));
    }

    public GameElt(String name, int x, int y) {
        setName(name);
        setHealth(100);
        setPos(new Position(x, y));
    }

    public void move(String dir) {
        moveStrat.move(pos, dir);
        if (moveStrat.chanceToFall()) {
            System.out.println(name + " fell down and lost 5 health!");
            setHealth(health - 5);
        }
    }

    public String getName() {
        return name;
    }

    public int getHealth() {
        return health;
    }

    public Position getPos() {
        return pos;
    }

    public MoveStrategy getMoveStrat() {
        return moveStrat;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setHealth(int health) {
        if (health < 0) {
            this.health = 0;
        } else if (health > 100) {
            this.health = 100;
        } else {
            this.health = health;
        }
    }

    public void setPos(Position pos) {
        this.pos = pos;
    }

    public void setMoveStrat(MoveStrategy moveStrat) {
        this.moveStrat = moveStrat;
    }

    public String toString() {
        return name + " the Hero " + pos;
    }
}
