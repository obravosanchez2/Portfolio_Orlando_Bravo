/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class BigDarnHero extends GameElt {

    public BigDarnHero() {
        super();
        setMoveStrat(new WalkMoveStrategy());
    }

    public BigDarnHero(String name, int x, int y) {
        super(name, x, y);
        setMoveStrat(new WalkMoveStrategy());
    }

    public void speedUp() {
        setMoveStrat(new RunMoveStrategy());
        System.out.println(getName() + " is now running!");
    }

    public void slowDown() {
        setMoveStrat(new WalkMoveStrategy());
        System.out.println(getName() + " is now walking!");
    }

    public void curse() {
        setMoveStrat(new RandomCursedMoveStrategy());
        System.out.println(getName() + " is now cursed!");
    }
}
