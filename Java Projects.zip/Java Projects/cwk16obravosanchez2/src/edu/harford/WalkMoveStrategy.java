/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class WalkMoveStrategy implements MoveStrategy {

    public void move(Position p, String dir) {
        int oldX = p.getX();
        int oldY = p.getY();

        if (dir.equalsIgnoreCase("N")) {
            p.setY(oldY + 1);
        } else if (dir.equalsIgnoreCase("S")) {
            p.setY(oldY - 1);
        } else if (dir.equalsIgnoreCase("E")) {
            p.setX(oldX + 1);
        } else if (dir.equalsIgnoreCase("W")) {
            p.setX(oldX - 1);
        }

        System.out.println("Walking from (" + oldX + "," + oldY + ") to " + p + ".");
    }

    public boolean chanceToFall() {
        return (int) (Math.random() * 20) == 0;
    }
}
