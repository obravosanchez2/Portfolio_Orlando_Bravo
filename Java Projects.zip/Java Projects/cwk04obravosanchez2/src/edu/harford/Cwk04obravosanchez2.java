/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Cwk04obravosanchez2 {
    
     /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Account a1 = new Account();
        Customer c1 = new Customer();
        a1.own = c1;
        c1.acct = a1;
        c1.acct.bal = 500.25;
        a1.own.name = "Orlando Bravo";
        System.out.println(c1);
        System.out.println(a1);
    }
}
