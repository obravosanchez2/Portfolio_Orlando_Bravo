/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import java.util.Locale;
import java.util.Random;

/**
 *
 * @author orlan
 */
public class Die {

    public static final int FACES;
    private static final int TARGET;
    private static final Random RNG = new Random();

    private int current;
    private int maxCount;
    private int minCount;

    static {
        int[] options = {4, 6, 8, 10, 12, 20};
        FACES = options[RNG.nextInt(options.length)];
        TARGET = 1 + RNG.nextInt(FACES);
    }

    public Die() {
        this.current = 1;
        this.maxCount = 0;
        this.minCount = 0;
    }

    public int getCurrent() {
        return current;
    }

    public void setCurrent(int current) {
        if (current >= 1 && current <= FACES) {
            this.current = current;
        }
    }

    public int getMaxCount() {
        return maxCount;
    }

    public void setMaxCount(int maxCount) {
        if (maxCount >= 0) {
            this.maxCount = maxCount;
        }
    }

    public int getMinCount() {
        return minCount;
    }

    public void setMinCount(int minCount) {
        if (minCount >= 0) {
            this.minCount = minCount;
        }
    }

    public void roll() {
        int value = 1 + RNG.nextInt(FACES);
        setCurrent(value);

        if (value == 1) {
            setMinCount(getMinCount() + 1);
        }
        if (value == FACES) {
            setMaxCount(getMaxCount() + 1);
        }
    }

    public static int sumDice(Die... dice) {
        int sum = 0;
        if (dice == null) {
            return sum;
        }
        for (Die d : dice) {
            if (d != null) {
                sum += d.getCurrent();
            }
        }
        return sum;
    }

    public static boolean sameDice(Die... dice) {
        if (dice == null || dice.length == 0) {
            return false;
        }
        int index = 0;
        while (index < dice.length && dice[index] == null) {
            index++;
        }
        if (index == dice.length) {
            return false;
        }
        int firstValue = dice[index].getCurrent();
        for (int i = index + 1; i < dice.length; i++) {
            if (dice[i] == null || dice[i].getCurrent() != firstValue) {
                return false;
            }
        }
        return true;
    }

    public static boolean differentDice(Die... dice) {
        if (dice == null || dice.length == 0) {
            return false;
        }
        for (int i = 0; i < dice.length; i++) {
            if (dice[i] == null) {
                return false;
            }
            for (int j = i + 1; j < dice.length; j++) {
                if (dice[j] == null) {
                    return false;
                }
                if (dice[i].getCurrent() == dice[j].getCurrent()) {
                    return false;
                }
            }
        }
        return true;
    }

    public static void dieStats(int howMany, int frequency) {
        if (howMany <= 0 || frequency <= 0) {
            return;
        }

        Die[] dice = new Die[howMany];
        for (int i = 0; i < howMany; i++) {
            dice[i] = new Die();
        }

        long sameCount = 0;
        long differentCount = 0;
        long sumAccumulator = 0;

        for (int trial = 0; trial < frequency; trial++) {
            for (Die d : dice) {
                d.roll();
            }
            if (sameDice(dice)) {
                sameCount++;
            }
            if (differentDice(dice)) {
                differentCount++;
            }
            sumAccumulator += sumDice(dice);
        }

        double avgSum = sumAccumulator / (double) frequency;

        System.out.printf(Locale.US,
                "How many dice: %d | Trials: %,d | FACES=%d%n",
                howMany, frequency, FACES);
        System.out.printf(Locale.US,
                "All same: %,d times (%.4f%%)%n",
                sameCount, 100.0 * sameCount / frequency);
        System.out.printf(Locale.US,
                "All different: %,d times (%.4f%%)%n",
                differentCount, 100.0 * differentCount / frequency);
        System.out.printf(Locale.US,
                "Average of sums: %.4f%n",
                avgSum);
    }

    public static int getTarget() {
        return TARGET;
    }

    public static void meetsTarget(int frequency) {
        if (frequency <= 0) {
            return;
        }

        Die d = new Die();
        long hits = 0;

        for (int i = 0; i < frequency; i++) {
            d.roll();
            if (d.getCurrent() >= TARGET) {
                hits++;
            }
        }

        System.out.printf(Locale.US,
                "TARGET=%d met or exceeded %,d out of %,d times (%.4f%%) with FACES=%d%n",
                TARGET, hits, frequency, 100.0 * hits / frequency, FACES);
    }
}
