/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

import java.util.Locale;
import java.util.Random;

/**
 *
 * @author orlan
 */
public class Cwk23obravosanchez2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("--- Die configuration for this run ---");
        System.out.println("FACES = " + Die.FACES);
        System.out.println("(EC) TARGET = " + Die.getTarget());

        Die d1 = new Die();
        Die d2 = new Die();
        Die d3 = new Die();

        System.out.println("\n--- Rolling three dice 5 times ---");
        for (int i = 1; i <= 5; i++) {
            d1.roll();
            d2.roll();
            d3.roll();

            int sum = Die.sumDice(d1, d2, d3);
            boolean same = Die.sameDice(d1, d2, d3);
            boolean diff = Die.differentDice(d1, d2, d3);

            System.out.printf(Locale.US,
                    "Roll %d -> d1=%d, d2=%d, d3=%d | sum=%d | allSame=%s | allDifferent=%s%n",
                    i,
                    d1.getCurrent(),
                    d2.getCurrent(),
                    d3.getCurrent(),
                    sum,
                    same,
                    diff);
        }

        System.out.printf(Locale.US,
                "\nDie#1 stats: minCount(1s)=%d, maxCount(%ds)=%d%n",
                d1.getMinCount(), Die.FACES, d1.getMaxCount());

        System.out.println("\n--- dieStats(howMany=5, frequency=10_000) ---");
        Die.dieStats(5, 10000);

        System.out.println("\n--- meetsTarget(frequency=50_000) ---");
        Die.meetsTarget(50000);
    }
}
