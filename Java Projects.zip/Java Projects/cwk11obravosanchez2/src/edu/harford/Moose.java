/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Moose extends ZooAnimal {
    public Moose() {
        super("Moose", 5);
    }

    @Override
    public void eat() {
        System.out.println(name + " is eating leaves from a tree.");
    }
}
