/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Camel extends ZooAnimal {
    public Camel() {
        super("Camel", 7);
    }

    public void storeWater() {
        System.out.println(name + " stores water in its hump.");
    }
}
