/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Elephant extends ZooAnimal {
    private double tuskLength;

    public Elephant() {
        super("Elephant", 10);
        this.tuskLength = 1.5;
    }

    public void trumpet() {
        System.out.println(name + " trumpets loudly!");
    }
}