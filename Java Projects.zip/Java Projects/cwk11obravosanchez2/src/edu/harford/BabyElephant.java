/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class BabyElephant extends Elephant {
    public BabyElephant() {
        super();
    }

    @Override
    public void sleep() {
        System.out.println("Baby Elephant is sleeping next to its mother.");
    }
}
