/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Cwk11obravosanchez2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Elephant e = new Elephant();
        Camel c = new Camel();
        Moose m = new Moose();
        BabyElephant be = new BabyElephant();

        e.eat();
        e.sleep();
        e.trumpet();

        System.out.println();

        c.eat();
        c.sleep();
        c.storeWater();

        System.out.println();

        m.eat();
        m.sleep();

        System.out.println();

        be.eat();
        be.sleep();
    }
}