/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

import java.util.Scanner;

/**
 *
 * @author orlan
 */
public class Cwk02obravosanchez2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int h1 = 90, h2 = 85, h3 = 87;
        double hAvg = (h1 + h2 + h3) / 3.0;
        System.out.println("Homework grades: " + h1 + ", " + h2 + ", " + h3);
        System.out.println("Homework average: " + hAvg);

        int c1 = 80, c2 = 95, c3 = 88;
        double cAvg = (c1 + c2 + c3) / 3.0;
        System.out.println("Classwork grades: " + c1 + ", " + c2 + ", " + c3);
        System.out.println("Classwork average: " + cAvg);

        int temp = c1;
        c1 = c2;
        c2 = temp;
        System.out.println("After swap: c1 = " + c1 + ", c2 = " + c2);

        System.out.print("Enter your test grade: ");
        int tg = scan.nextInt();

        double grade = (0.4 * hAvg) + (0.5 * cAvg) + (0.1 * tg);
        System.out.println("Final grade = " + grade);
    }
}