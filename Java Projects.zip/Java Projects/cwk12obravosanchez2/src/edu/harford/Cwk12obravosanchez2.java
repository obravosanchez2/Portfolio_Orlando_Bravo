/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Cwk12obravosanchez2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Employee[] staff = {
            new Employee("Basic Bob"),
            new SalariedEmployee("Alice", 60000, 12),
            new SalariedEmployee("John", 50000, 10),
            new HourlyEmployee("Tim", 20.0, 40),
            new HourlyEmployee("Sue", 25.0, 45),
            new AdjunctEmployee("Carlos", 9),
            new AdjunctEmployee("Mia", 12)
        };

        Employee highest = staff[0];
        for (Employee emp : staff) {
            emp.reportDeposit();
            if (emp.paycheck() > highest.paycheck()) {
                highest = emp;
            }
        }

        System.out.println("Highest paycheck goes to: " + highest.getName()
                + " with $" + String.format("%.2f", highest.paycheck()));
    }
}
