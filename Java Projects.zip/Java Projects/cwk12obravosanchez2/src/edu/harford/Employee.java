/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class Employee {
    protected String name;

    public Employee(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name != null && !name.isEmpty()) {
            this.name = name;
        }
        // no borra el nombre bueno si recibe algo inválido
    }

    public double paycheck() {
        return 0.0;
    }

    public void reportDeposit() {
        double gross = paycheck();
        double taxes = gross * 0.17;
        double net = gross - taxes;
        System.out.println("Employee: " + name);
        System.out.printf("Gross: $%.2f | Taxes: $%.2f | Net: $%.2f\n", gross, taxes, net);
        System.out.println();
    }
}
