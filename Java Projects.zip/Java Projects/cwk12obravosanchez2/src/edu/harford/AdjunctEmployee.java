/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class AdjunctEmployee extends Employee {
    private int credits;
    private static final double PAY_PER_CREDIT = 827.0;

    public AdjunctEmployee(String name, int credits) {
        super(name);
        setCredits(credits);
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        if (credits >= 0 && credits <= 18) {
            this.credits = credits;
        }
    }

    @Override
    public double paycheck() {
        double total = credits * PAY_PER_CREDIT;
        return total / (4 * 2.0); // 4 meses * 2 pagos
    }
}
