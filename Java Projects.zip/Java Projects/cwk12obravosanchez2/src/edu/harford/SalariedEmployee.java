/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class SalariedEmployee extends Employee {
    private double annualSalary;
    private int months;

    public SalariedEmployee(String name, double annualSalary, int months) {
        super(name);
        setAnnualSalary(annualSalary);
        setMonths(months);
    }

    public double getAnnualSalary() {
        return annualSalary;
    }

    public void setAnnualSalary(double annualSalary) {
        if (annualSalary > 0) {
            this.annualSalary = annualSalary;
        }
    }

    public int getMonths() {
        return months;
    }

    public void setMonths(int months) {
        if (months == 10 || months == 12) {
            this.months = months;
        }
    }

    @Override
    public double paycheck() {
        return annualSalary / (months * 2.0);
    }
}
