/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class HourlyEmployee extends Employee {
    private double hourlyRate;
    private int hoursPerWeek;

    public HourlyEmployee(String name, double hourlyRate, int hoursPerWeek) {
        super(name);
        setHourlyRate(hourlyRate);
        setHoursPerWeek(hoursPerWeek);
    }

    public double getHourlyRate() {
        return hourlyRate;
    }

    public void setHourlyRate(double hourlyRate) {
        if (hourlyRate > 0) {
            this.hourlyRate = hourlyRate;
        }
    }

    public int getHoursPerWeek() {
        return hoursPerWeek;
    }

    public void setHoursPerWeek(int hoursPerWeek) {
        if (hoursPerWeek > 0) {
            this.hoursPerWeek = hoursPerWeek;
        }
    }

    @Override
    public double paycheck() {
        int overtime = 0;
        if (hoursPerWeek > 40) {
            overtime = hoursPerWeek - 40;
        }

        double overtimeRate = hourlyRate * 1.05;
        double weeklyPay = (40 * hourlyRate) + (overtime * overtimeRate);
        return weeklyPay * 2;
    }
}
