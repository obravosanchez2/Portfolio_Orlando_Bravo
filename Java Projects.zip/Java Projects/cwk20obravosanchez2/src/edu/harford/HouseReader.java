/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import java.util.*;

/**
 *
 * @author orlan
 */
public class HouseReader {

    public static void main(String[] args) {

        System.out.println("Reading houses.csv:");
        List<HouseListing> list1 = HouseListing.readFile("houses.csv");
        for (HouseListing h : list1) {
            System.out.println(h);
        }

        System.out.println("\nReading newHouses.csv:");
        List<HouseListing> list2 = HouseListing.readFile("newHouses.csv");
        for (HouseListing h : list2) {
            System.out.println(h);
        }
    }
}
