/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

import java.util.*;

/**
 *
 * @author orlan
 */
public class Cwk20obravosanchez2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        List<HouseListing> list = new ArrayList<>();

        list.add(new HouseListing("1313 Mockingbird Lane", 312000, 5));
        list.add(new HouseListing("23 The Pines", 252000, 3));
        list.add(new HouseListing("6 French Ave.", 188000, 2));

        System.out.println("Add a new house:");

        String address = "";
        int price = 0;
        int bedrooms = 0;

        boolean ok = false;
        while (!ok) {
            try {
                System.out.print("Address: ");
                address = in.nextLine();
                if (address.trim().isEmpty()) {
                    throw new IllegalArgumentException("Address cannot be empty.");
                }
                ok = true;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        ok = false;
        while (!ok) {
            try {
                System.out.print("Price: ");
                price = Integer.parseInt(in.nextLine());
                if (price <= 0) {
                    throw new IllegalArgumentException("Price must be positive.");
                }
                ok = true;
            } catch (NumberFormatException e) {
                System.out.println("Price must be a number.");
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        ok = false;
        while (!ok) {
            try {
                System.out.print("Bedrooms: ");
                bedrooms = Integer.parseInt(in.nextLine());
                if (bedrooms <= 0) {
                    throw new IllegalArgumentException("Bedrooms must be positive.");
                }
                ok = true;
            } catch (NumberFormatException e) {
                System.out.println("Bedrooms must be a number.");
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        list.add(new HouseListing(address, price, bedrooms));

        HouseListing.writeFile(list, "newHouses.csv");

        System.out.println("newHouses.csv written successfully.");
    }
}
