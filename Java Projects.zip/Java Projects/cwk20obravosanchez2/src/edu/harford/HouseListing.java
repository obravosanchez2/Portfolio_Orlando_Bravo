/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import java.io.*;
import java.util.*;

/**
 *
 * @author orlan
 */
public class HouseListing {

    private String address;
    private int price;
    private int bedrooms;

    public HouseListing() {
        address = "";
        price = 0;
        bedrooms = 0;
    }

    public HouseListing(String address, int price, int bedrooms) {
        this();
        setAddress(address);
        setPrice(price);
        setBedrooms(bedrooms);
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String a) {
        if (a == null || a.trim().isEmpty()) {
            throw new IllegalArgumentException("Address cannot be empty.");
        }
        address = a;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int p) {
        if (p <= 0) {
            throw new IllegalArgumentException("Price must be positive.");
        }
        price = p;
    }

    public int getBedrooms() {
        return bedrooms;
    }

    public void setBedrooms(int b) {
        if (b <= 0) {
            throw new IllegalArgumentException("Bedrooms must be positive.");
        }
        bedrooms = b;
    }

    public String toCSV() {
        return address + "," + price + "," + bedrooms;
    }

    public static HouseListing fromCSV(String line) {
        try {
            String[] parts = line.split(",");
            if (parts.length != 3) {
                return null;
            }

            String addr = parts[0].trim();
            int price = Integer.parseInt(parts[1].trim());
            int beds = Integer.parseInt(parts[2].trim());

            return new HouseListing(addr, price, beds);
        } catch (Exception e) {
            return null;
        }
    }

    public static void writeFile(List<HouseListing> list, String filename) {
        try (PrintWriter out = new PrintWriter(new FileWriter(filename))) {
            for (HouseListing h : list) {
                out.println(h.toCSV());
            }
        } catch (IOException e) {
            System.out.println("Error writing file: " + e.getMessage());
        }
    }

    public static List<HouseListing> readFile(String filename) {
        List<HouseListing> results = new ArrayList<>();
        try (Scanner scan = new Scanner(new File(filename))) {
            while (scan.hasNextLine()) {
                String line = scan.nextLine();
                HouseListing h = HouseListing.fromCSV(line);
                if (h == null) {
                    System.out.println("Invalid line skipped: " + line);
                } else {
                    results.add(h);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Cannot open file: " + filename);
        }
        return results;
    }

    public String toString() {
        return address + " ($" + price + "), " + bedrooms + " bedrooms";
    }
}
