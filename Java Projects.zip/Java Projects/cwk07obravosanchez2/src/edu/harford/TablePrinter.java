/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

/**
 *
 * @author orlan
 */
public class TablePrinter {

    public static void printSumTable(int low, int high) {
        System.out.println();
        System.out.print("      ");

        for (int c = low; c <= high; c++) {
            System.out.printf("%4d", c);
        }
        System.out.println();

        System.out.print("    ");
        for (int i = low; i <= high; i++) {
            System.out.print("----");
        }
        System.out.println();

        for (int r = low; r <= high; r++) {
            System.out.printf("%3d |", r);
            for (int c = low; c <= high; c++) {
                System.out.printf("%4d", r + c);
            }
            System.out.println();
        }
    }
}
