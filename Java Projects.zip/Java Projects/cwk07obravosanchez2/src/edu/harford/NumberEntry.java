/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import java.util.Scanner;

/**
 *
 * @author orlan
 */
public class NumberEntry {

    public static void enterNumbers(Scanner in) {
        int[] nums = new int[10];
        int count = 0;

        while (count < 10) {
            System.out.print("Enter number #" + (count + 1) + ": ");
            int val = in.nextInt();
            while (val < 0 || val > 100) {
                System.out.print("Invalid. Enter again (0–100): ");
                val = in.nextInt();
            }
            nums[count] = val;
            count++;
        }

        int largest = Integer.MIN_VALUE;
        int second = Integer.MIN_VALUE;

        for (int n : nums) {
            if (n > largest) {
                second = largest;
                largest = n;
            } else if (n > second) {
                second = n;
            }
        }

        System.out.println("Largest number: " + largest);
        System.out.println("Second largest: " + second);
    }
}
