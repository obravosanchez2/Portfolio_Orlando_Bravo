/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.harford;

import java.util.Scanner;

/**
 *
 * @author orlan
 */
public class Cwk07obravosanchez2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        MAIN:
        while (true) {
            System.out.println("\nMAIN MENU");
            System.out.println("1. Enter Numbers");
            System.out.println("2. Draw Tables");
            System.out.println("3. Quit");
            System.out.print("Choose: ");

            int choice = in.nextInt();

            switch (choice) {
                case 1:
                    NumberEntry.enterNumbers(in);
                    break;
                case 2:
                    TableMenu.drawTables(in);
                    break;
                case 3:
                    System.out.println("Goodbye!");
                    break MAIN;
                default:
                    System.out.println("Invalid choice");
            }
        }

        in.close();
    }
}
