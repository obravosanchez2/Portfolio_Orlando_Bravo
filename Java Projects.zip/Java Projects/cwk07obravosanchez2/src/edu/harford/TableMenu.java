/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.harford;

import java.util.Scanner;

/**
 *
 * @author orlan
 */
public class TableMenu {

    public static void drawTables(Scanner in) {
        int low = 1;
        int high = 10;

        TABLES:
        while (true) {
            System.out.println("\nTABLE MENU");
            System.out.println("1. Choose Range");
            System.out.println("2. Sum Table");
            System.out.println("3. Return to Main Menu");
            System.out.println("4. RageQuit");
            System.out.print("Choose: ");

            int choice = in.nextInt();

            switch (choice) {
                case 1:
                    boolean valid = false;
                    while (!valid) {
                        System.out.print("Enter low (1–10): ");
                        int newLow = in.nextInt();
                        System.out.print("Enter high (1–10): ");
                        int newHigh = in.nextInt();
                        if (newLow >= 1 && newHigh <= 10 && newLow < newHigh) {
                            low = newLow;
                            high = newHigh;
                            valid = true;
                        } else {
                            System.out.println("Invalid range. Try again.");
                        }
                    }
                    break;

                case 2:
                    TablePrinter.printSumTable(low, high);
                    break;

                case 3:
                    return;

                case 4:
                    System.out.println("YOU RAGEQUIT THE WHOLE PROGRAM!");
                    break TABLES;

                default:
                    System.out.println("Invalid choice");
            }
        }
    }
}
